package com.luv2code.springboot.thymeleafdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
